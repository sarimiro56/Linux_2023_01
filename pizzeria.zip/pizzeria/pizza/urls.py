"""Pizza 홈페이지 URL맵핑을 위한 파일"""

from django.urls import path

from . import views

app_name = 'pizza'
urlpatterns = [
        # 홈 페이지
        path('', views.index, name='index'),
        path('topics/', views.topics, name='topics'),
        # 단일 토픽에 대한 세부 페이지들
        path('topics/<int:topic_id>/', views.topic, name='topic'),
]
