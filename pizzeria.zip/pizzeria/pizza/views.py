from django.shortcuts import render
from .models import Topic

# Create your views here.
def index(request):
    """ Pizza 메뉴 홈페이지 """
    return render(request, 'pizza/index.html')

def topics(request):
    """ Show all topics."""
    topics = Topic.objects.order_by('date_add')
    context = {'topics': topics}
    return render(request, 'pizza/topics.html', context)
    
def topic(request, topic_id):
    topic = Topic.objects.get(id=topic_id)
    entries = topic.entry_set.order_by('-date_add')
    context = {'topic':topic, 'entries':entries}
    return render(request, 'pizza/topic.html',context)
