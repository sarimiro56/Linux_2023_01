""" 사용자들을 위한 URL 패턴 정의"""
from django.urls import path, include
from . import views

app_name = 'users'

urlpatterns = [
        #기본 auth urls 포함
        path('', include('django.contrib.auth.urls')),
        #등록 페이지
        path('register/', views.register, name='register'),
        ]
