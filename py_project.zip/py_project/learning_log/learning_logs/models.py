from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Topic(models.Model):
    """ 사용자가 학습한 주제"""
    text = models.CharField(max_length=200)
    date_add = models.DateTimeField(auto_now_add=True)
    owner = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        """ Return a string representation of model."""
        return self.text

class Entry(models.Model):
    """ 토픽에 대한 학습한 내용들"""
    topic = models.ForeignKey(Topic, on_delete=models.CASCADE)
    text = models.TextField()
    date_add = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = 'entries'

    def __str__(self):
        """ Return a string representation of the model."""
        return self.text
